/**
 * Created by gxlzlihao on 16/5/13.
 */

$(document).ready(function(){

    $('div#top_bar').children('div#top_back_button').click(function(){
        window.history.go(-1);
    });

});

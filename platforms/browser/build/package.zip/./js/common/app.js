/**
 * Created by weiwenjun on 16/6/28.
 */
angular.module('starter',['ngCordova']);
